const $ = id => document.getElementById(id);
const shapes = {
  download:'<path d="M12 3v12m-5-5 5 5 5-5M4 15v5h16v-5"/>',
  history:'<path d="M3 11a9 9 0 1 1 2.5 7M3 4v7h7m2-4v5l3 2"/>',
  help:'<circle cx="12" cy="12" r="9"/><path d="M9.6 9a2.5 2.5 0 0 1 5 .4c0 2-2.6 2.1-2.6 4M12 17h.01"/>',
  link:'<path d="m10 13 4-4m-5 6-1.7 1.7a3.5 3.5 0 0 1-5-5l4-4a3.5 3.5 0 0 1 5 0m1-1 1.7-1.7a3.5 3.5 0 0 1 5 5l-4 4a3.5 3.5 0 0 1-5 0"/>',
  clipboard:'<rect x="5" y="5" width="14" height="16" rx="2"/><rect x="9" y="3" width="6" height="4" rx="1" fill="white"/>',
  arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',
  youtube:'<path d="M22 7.5c-.3-1.7-1-2.5-2.8-2.8a59 59 0 0 0-14.4 0C3 5 2.3 5.8 2 7.5a27 27 0 0 0 0 9c.3 1.7 1 2.5 2.8 2.8a59 59 0 0 0 14.4 0c1.8-.3 2.5-1.1 2.8-2.8a27 27 0 0 0 0-9z"/><path fill="#fff" d="m10 8 6 4-6 4z"/>',
  archive:'<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9m-9 4h4"/>',
  x:'<path d="m6 6 12 12M18 6 6 18"/>'
};
function icons(root = document) {
  root.querySelectorAll('i[data-icon]').forEach(el => {
    el.setAttribute('aria-hidden','true');
    el.innerHTML = '<svg viewBox="0 0 24 24">' + shapes[el.dataset.icon] + '</svg>';
  });
}
icons();
const storageKey = 'spool.history.v1';
let entries = [];
try {
  const data = JSON.parse(localStorage.getItem(storageKey) || '[]');
  if (Array.isArray(data)) entries = data.filter(item => item && (item.kind === 'playlist' ? /^[\w-]{2,128}$/ : /^[\w-]{11}$/).test(item.id) && typeof item.format === 'string' && typeof item.title === 'string').slice(0,50);
} catch {}
let current = null;
let busy = false;
function persist() {
  try { localStorage.setItem(storageKey, JSON.stringify(entries)); } catch {}
  renderHistory();
}
function setView(history) {
  document.body.classList.toggle('history-mode',history);
  $('hero').hidden = history;
  $('download-panel').hidden = history;
  for (const [id,active] of [['nav-down',!history], ['nav-history',history]]) {
    $(id).classList.toggle('active',active);
    if (active) $(id).setAttribute('aria-current','page');
    else $(id).removeAttribute('aria-current');
  }
  window.scrollTo(0,0);
}
$('nav-down').onclick = () => setView(false);
$('nav-history').onclick = () => setView(true);
$('help').onclick = () => $('guide').showModal();
document.querySelector('#guide .close').onclick = () => $('guide').close();
$('guide').onclick = e => {
  if (e.target !== $('guide')) return;
  const r = $('guide').getBoundingClientRect();
  if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) $('guide').close();
};
function renderHistory() {
  const section = $('history-items');
  section.replaceChildren();
  $('count').textContent = entries.length;
  $('clear').hidden = !entries.length;
  if (!entries.length) {
    section.innerHTML = '<div class="empty"><span class="empty-icon"><i data-icon="archive"></i></span><div><b>No downloads yet</b><p>Your downloaded videos and audio will appear here.</p></div></div>';
    icons(section);
  }
  for (const item of entries) {
    const row = document.createElement('article');
    row.className = 'record';
    row.innerHTML = '<img alt=""><div><b></b><p></p></div><button type="button">Fetch again <i data-icon="arrow"></i></button>';
    row.querySelector('img').src = item.kind === 'playlist' ? '/icon.svg' : 'https://i.ytimg.com/vi/' + item.id + '/default.jpg';
    row.querySelector('b').textContent = item.title;
    row.querySelector('p').textContent = (item.kind === 'playlist' ? 'Playlist ZIP · ' : '') + item.format.toUpperCase() + (item.height ? ' · ' + item.height + 'p' : '') + ' · ' + new Date(item.date).toLocaleDateString();
    const button = row.querySelector('button');
    button.disabled = busy;
    button.onclick = () => {
      setView(false);
      $('url').value = mediaUrl(item);
      linkChanged();
      $('lookup').requestSubmit();
    };
    icons(row);
    section.append(row);
  }
}
renderHistory();
$('clear').onclick = () => {
  if (window.confirm('Clear the download history on this device? Your saved files will stay in your downloads folder.')) { entries = []; persist(); }
};
function feedback(message = '',error = false) {
  $('feedback').textContent = message;
  $('feedback').hidden = !message;
  $('feedback').classList.toggle('error',error);
}
function lock(value) {
  busy = value;
  for (const id of ['fetch','paste','url','download','quality','mode','playlist-scope']) $(id).disabled = value;
  document.querySelectorAll('.record button').forEach(btn => { btn.disabled = value; });
}
function resetPreview() {
  current = null;
  $('matches').replaceChildren();
  $('video-mode').disabled = false;
  $('result').hidden = true;
  $('progress').hidden = true;
  $('save-again').hidden = true;
  feedback();
}
function mediaUrl(item) {
  return item.kind === 'playlist' ? 'https://www.youtube.com/playlist?list=' + item.id : 'https://youtu.be/' + item.id;
}
function isLink(value) {
  return /^(?:https?:\/\/|(?:[\w-]+\.)*(?:youtube\.com|youtu\.be)(?:\/|$))/i.test(value);
}
function renderMatches(items) {
  for (const item of items) {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'search-match';
    row.innerHTML = '<img alt=""><span><strong></strong><small></small></span>';
    row.querySelector('img').src = 'https://i.ytimg.com/vi/' + item.id + '/default.jpg';
    row.querySelector('strong').textContent = item.title;
    row.querySelector('small').textContent = [item.channel, item.duration ? duration(item.duration) : ''].filter(Boolean).join(' · ');
    row.onclick = () => {
      $('url').value = mediaUrl(item);
      linkChanged();
      $('lookup').requestSubmit();
    };
    $('matches').append(row);
  }
  feedback(items.length ? 'Select a video to see download options.' : 'No videos found. Try different keywords.');
}
function linkChanged() {
  $('fetch').querySelector('span').textContent = isLink($('url').value.trim()) ? 'Fetch link' : 'Search';
  resetPreview();
  $('scope-wrap').hidden = true;
  $('playlist-scope').checked = false;
  try {
    const value = $('url').value.trim();
    const url = new URL(/^https?:\/\//i.test(value) ? value : 'https://' + value);
    const video = url.hostname === 'youtu.be' || (['youtube.com','www.youtube.com','music.youtube.com','m.youtube.com'].includes(url.hostname)
      && (url.searchParams.has('v') || /^\/(shorts|live|embed)\/(?!videoseries)/.test(url.pathname)));
    $('scope-wrap').hidden = !(video && url.searchParams.has('list'));
  } catch {}
}
$('url').oninput = linkChanged;
$('playlist-scope').onchange = resetPreview;
$('paste').onclick = async () => {
  try {
    const value = await navigator.clipboard.readText();
    if (!value.trim()) throw new Error();
    $('url').value = value.trim();
    linkChanged();
  } catch { feedback('Paste your link into the field using Ctrl+V, or use the paste menu on mobile.'); }
  $('url').focus();
};
async function api(path, data) {
  const response = await fetch(path, data ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)} : {});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'The request failed. Please try again.');
  return result;
}
function duration(seconds) {
  const time = [Math.floor(seconds / 60),String(seconds % 60).padStart(2,'0')];
  if (seconds >= 3600) time.splice(0,1,Math.floor(seconds / 3600),String(time[0] % 60).padStart(2,'0'));
  return time.join(':');
}
$('lookup').onsubmit = async e => {
  e.preventDefault();
  if (busy) return;
  resetPreview();
  const url = $('url').value.trim();
  if (!url) { feedback('Enter keywords or a YouTube link.',true); $('url').focus(); return; }
  lock(true);
  $('fetch').querySelector('span').textContent = 'Fetching…';
  feedback(isLink(url) ? 'Looking up your link…' : 'Searching YouTube…');
  try {
    if (!isLink(url)) {
      renderMatches(await api('/api/search', {query:url}));
      return;
    }
    current = await api('/api/video',{url, scope:$('playlist-scope').checked ? 'playlist' : 'video'});
    const playlist = current.kind === 'playlist';
    $('thumbnail').src = current.thumbnail;
    $('video-title').textContent = current.title;
    $('video-meta').textContent = [current.channel, playlist ? current.count + ' tracks' : duration(current.duration)].join(' · ');
    $('download').querySelector('span').textContent = playlist ? 'Download playlist ZIP' : 'Download file';
    $('video-mode').disabled = !current.qualities.length;
    if (!current.qualities.length) $('audio-mode').checked = true;
    $('quality').replaceChildren(...current.qualities.map(h => new Option((playlist ? 'Up to ' : '') + h + 'p',h)));
    if (current.qualities.includes(1080)) $('quality').value = 1080;
    updateMode();
    $('result').hidden = false;
    feedback();
  } catch (err) { feedback(err.message,true); }
  finally { lock(false); $('fetch').querySelector('span').textContent = isLink(url) ? 'Fetch link' : 'Search'; }
};
function updateMode() {
  const audio = $('audio-mode').checked;
  $('quality-wrap').hidden = audio;
  $('download').querySelector('span').textContent = current?.kind === 'playlist' ? 'Download playlist ZIP' : audio ? 'Download MP3' : 'Download video';
  $('progress').hidden = true;
  $('save-again').hidden = true;
}
$('mode').onchange = updateMode;
async function getFile(request, meter, status) {
  const { id } = await api('/api/jobs',request);
  while (true) {
    await new Promise(resolve => setTimeout(resolve,900));
    const job = await api('/api/jobs/' + id);
    if (job.state === 'failed') throw new Error(job.error);
    if (job.state === 'ready') return {file:'/api/jobs/' + id + '/file', message:job.message};
    if (job.message || job.progress > 0) {
      meter.value = job.progress;
      status.textContent = job.message || (job.progress >= 99 ? 'Finishing your file…' : 'Downloading media · ' + Math.round(job.progress) + '%');
    }
  }
}
$('download').onclick = async () => {
  if (!current || busy) return;
  lock(true);
  const format = $('audio-mode').checked ? 'mp3' : 'mp4';
  const height = format === 'mp4' ? Number($('quality').value) : null;
  const meter = $('progress').querySelector('progress');
  const status = $('progress').querySelector('span');
  $('save-again').hidden = true;
  $('progress').hidden = false;
  $('progress').classList.remove('error');
  meter.hidden = false;
  meter.removeAttribute('value');
  status.textContent = 'Preparing your file…';
  try {
    const {file, message} = await getFile({url:mediaUrl(current),format,height}, meter, status);
    meter.value = 100;
    status.textContent = (message || 'File ready.') + ' Your download will start automatically.';
    const save = $('save-again');
    save.href = file;
    save.download = current.title + '.' + (current.kind === 'playlist' ? 'zip' : format);
    save.hidden = false;
    save.click();
    entries.unshift({kind:current.kind,id:current.id,title:current.title,format,height,date:Date.now()});
    entries = entries.slice(0,50);
    persist();
  } catch (error) {
    meter.hidden = true;
    $('progress').classList.add('error');
    status.textContent = error.message;
  } finally { lock(false); }
};
let updateBusy = false;
let availableUpdate;
function offerRestart(version) {
  const action = $('update-action');
  const message = $('update-message');
  message.textContent = 'Version ' + version + ' is installed and ready to start.';
  action.textContent = 'Restart Spool';
  action.hidden = false;
  action.onclick = async () => {
    if (updateBusy) return;
    updateBusy = true;
    action.disabled = true;
    try {
      await api('/api/updates/restart', {version});
      message.textContent = 'Restarting Spool…';
      for (let attempt = 0; attempt < 60; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        try {
          const response = await fetch('/api/status', {cache:'no-store', signal:AbortSignal.timeout(1000)});
          if ((await response.json()).appVersion === version) { location.reload(); return; }
        } catch {}
      }
      throw new Error('Restart took longer than expected. Reopen Spool from its launcher.');
    } catch (error) { message.textContent = error.message; }
    finally { action.disabled = false; updateBusy = false; }
  };
}
async function updateSpool(install = false) {
  if (updateBusy) return;
  updateBusy = true;
  const action = $('update-action');
  const message = $('update-message');
  action.hidden = true;
  message.textContent = install ? 'Downloading and verifying the update…' : 'Checking GitHub Releases…';
  try {
    if (install) {
      const result = await api('/api/updates/install', {version: availableUpdate});
      offerRestart(result.version);
      return;
    }
    const result = await api('/api/updates/check', {});
    availableUpdate = result.latest;
    if (!result.available) {
      message.textContent = 'You’re up to date. You’re running Spool ' + result.current + '.';
    } else if (result.staged) {
      offerRestart(result.latest);
    } else if (!result.packaged) {
      message.textContent = 'Version ' + result.latest + ' is available. This copy runs from source. Use the Windows edition for in-app updates.';
    } else {
      message.textContent = 'You’re running ' + result.current + '. Version ' + result.latest + ' is ready to install.';
      action.textContent = 'Install update';
      action.onclick = () => updateSpool(true);
      action.hidden = false;
    }
  } catch (error) {
    message.textContent = error.message;
    action.textContent = 'Check again';
    action.onclick = () => updateSpool();
    action.hidden = false;
  } finally { updateBusy = false; }
}
$('check-updates').onclick = () => {
  $('updates').showModal();
  void updateSpool();
};
