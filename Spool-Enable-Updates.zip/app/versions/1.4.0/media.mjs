import { execFile, spawn } from 'node:child_process';
import { mkdir, mkdtemp, rename, rm, stat, writeFile } from 'node:fs/promises';
import { promisify } from 'node:util';
import path from 'node:path';
import { downloader, ffmpeg } from './setup.mjs';
const metadata = new Map();

class InputError extends Error {}
function resolveLink(input, scope) {
  let url;
  try {
    const raw = String(input).trim();
    url = new URL(/^https?:\/\//i.test(raw) ? raw : 'https://' + raw);
  } catch { throw new InputError('Paste a YouTube video or playlist link.'); }
  const host = url.hostname.toLowerCase();
  const parts = url.pathname.split('/');
  let id;
  if (host === 'youtu.be') id = parts[1];
  const youtube = ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'].includes(host);
  if (youtube) {
    if (url.pathname === '/watch') id = url.searchParams.get('v');
    else if (['shorts', 'live', 'embed'].includes(parts[1])) id = parts[2];
  }
  const list = url.searchParams.get('list');
  const playlistPage = youtube && ['/playlist', '/embed/videoseries'].includes(url.pathname);
  if (playlistPage || (scope === 'playlist' && (youtube || host === 'youtu.be') && id)) {
    if (!/^[\w-]{2,128}$/.test(list || '')) throw new InputError('Use a YouTube playlist link with a valid list ID.');
    if (list.startsWith('RD') && !list.startsWith('RDCLAK')) throw new InputError('YouTube Mixes change as they play. Choose a saved playlist with a fixed track list.');
    return {kind:'playlist', id:list, url:'https://www.youtube.com/playlist?list=' + list};
  }
  if (!/^[\w-]{11}$/.test(id || '')) throw new InputError('Use a YouTube video, Short, or playlist link.');
  return {kind:'video', id, url:'https://www.youtube.com/watch?v=' + id};
}

function run(args, timeout, onProgress) {
  return new Promise((resolve, reject) => {
    const proc = spawn(downloader, ['--ignore-config', '--no-playlist', '--no-warnings',
      '--encoding', 'utf-8', '--js-runtimes', 'node:' + process.execPath,
      ...(ffmpeg ? ['--ffmpeg-location', ffmpeg] : []), '--socket-timeout', '20', '--retries', '2', ...args],
      { windowsHide: true, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '', errors = '', partial = '';
    const timer = setTimeout(() => proc.kill(), timeout);
    proc.stdout.setEncoding('utf8').on('data', chunk => {
      if (!onProgress) { output += chunk; return; }
      const lines = (partial + chunk).split(/\r?\n/);
      partial = lines.pop();
      lines.forEach(onProgress);
    });
    proc.stderr.setEncoding('utf8').on('data', chunk => { errors = (errors + chunk).slice(-4000); });
    proc.on('error', err => { clearTimeout(timer); reject(err); });
    proc.on('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve(output);
      else reject(new Error(errors.trim() || 'The download timed out or was interrupted.'));
    });
  });
}

export async function searchVideos(query) {
  if (typeof query !== 'string' || !query.trim() || query.length > 200 || /[\x00-\x1f]/.test(query)) {
    throw new InputError('Enter a search of 1 to 200 characters.');
  }
  if (lookups >= 4) throw new InputError('Other searches are running. Try again in a moment.');
  lookups++;
  try {
    const output = await run(['--flat-playlist', '--dump-single-json', '--', 'ytsearch8:' + query.trim()], 60000);
    return (JSON.parse(output).entries || []).filter(item => /^[\w-]{11}$/.test(item?.id || '') && !['is_live','is_upcoming'].includes(item.live_status))
      .map(item => ({id:item.id, title:item.title || 'Untitled video', channel:item.channel || item.uploader || '', duration:Math.floor(item.duration || 0)}));
  } finally { lookups--; }
}

function friendly(error) {
  if (error instanceof InputError) return error.message;
  const detail = error.message;
  if (/playlist.*(?:does not exist|private|unavailable)/i.test(detail)) return 'YouTube could not open that playlist. Check that the link opens without signing in.';
  if (/format is not available/i.test(detail)) return 'That format is no longer available. Fetch the link again to refresh the options.';
  if (/private|unavailable|removed|not available|members.only/i.test(detail)) return 'YouTube says this item is unavailable.';
  if (/sign in|bot|429|403|age.restricted/i.test(detail)) return 'YouTube restricted this request. Try another public video or try again later.';
  if (/ENOENT|ffmpeg not found/i.test(detail)) return 'A media tool is missing. Close Spool and open it again to restore the tools.';
  return 'The request could not finish. Check your connection and try again.';
}

let lookups = 0;
async function inspect(input, scope) {
  const {kind, id, url} = resolveLink(input, scope);
  const cached = metadata.get(url);
  if (cached && Date.now() - cached.time < 600000) return cached.data;
  if (lookups >= 4) throw new InputError('Other links are loading. Try again in a moment.');
  lookups++;
  try {
    const flat = kind === 'playlist' ? ['--yes-playlist', '--flat-playlist'] : [];
    const raw = JSON.parse(await run([...flat, '--dump-single-json', '--skip-download', '--', url], kind === 'playlist' ? 300000 : 90000));
    let data;
    if (kind === 'playlist') {
      const entries = (raw.entries || []).map(item => ({
        id: /^[\w-]{11}$/.test(item?.id || '') ? item.id : null,
        title: item?.title || 'Untitled video',
        unavailable: ['private','premium_only','subscriber_only','needs_auth'].includes(item?.availability)
          || ['is_live','is_upcoming'].includes(item?.live_status)
      }));
      if (!entries.length) throw new InputError('This playlist has no videos available to download.');
      const cover = entries.find(item => item.id && !item.unavailable);
      data = {kind, id, title:raw.title || 'YouTube playlist', channel:raw.uploader || raw.channel || 'YouTube',
        thumbnail:cover ? 'https://i.ytimg.com/vi/' + cover.id + '/hqdefault.jpg' : '/icon.svg',
        count:entries.length, qualities:[2160, 1440, 1080, 720, 480, 360], entries};
    } else {
      data = videoDetails(raw, id);
    }
    if (metadata.size >= 100) metadata.delete(metadata.keys().next().value);
    metadata.set(url, {time:Date.now(), data});
    return data;
  } finally { lookups--; }
}

function videoDetails(raw, id) {
  if (raw.is_live || raw.live_status === 'is_upcoming') throw new InputError('Choose a finished video. Live broadcasts can be saved after they end.');
  const videoFormats = raw.formats.filter(f => f.ext === 'mp4' && !f.has_drm &&
    f.vcodec && f.vcodec !== 'none' && Number.isInteger(f.height) && f.height > 0);
  const choices = [...new Set(videoFormats.map(f => f.height))].sort((a,b) => b-a);
  return { kind:'video', id, title: raw.title, channel: raw.uploader || raw.channel || 'YouTube',
    duration: raw.duration || 0, qualities: choices, thumbnail: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' };
}

async function downloadTrack(id, format, height, directory, playlist, timeout, progress) {
  const resolution = '[height' + (playlist ? '<=' : '=') + height + ']';
  const options = format === 'mp3'
    ? ['-f', 'bestaudio/best', '-x', '--audio-format', 'mp3', '--audio-quality', '2']
    : ['-f', 'bv[ext=mp4]' + resolution + '+ba[ext=m4a]/b[ext=mp4]' + resolution + '/bv[ext=mp4]' + resolution + '+ba', '--merge-output-format', 'mp4'];
  await run([...options, '--newline', '--progress', '--progress-template', 'download:PROGRESS %(progress._percent_str)s',
    '--match-filter', '!is_live & live_status!=is_upcoming',
    '-o', path.join(directory, 'video.%(ext)s'), '--', 'https://www.youtube.com/watch?v=' + id], timeout, line => {
    const match = /^PROGRESS\s+([\d.]+)%/.exec(line);
    if (match) progress(Math.min(99, Number(match[1])));
  });
  const file = path.join(directory, 'video.' + format);
  const info = await stat(file).catch(error => {
    if (error.code === 'ENOENT') throw new InputError('This video is unavailable or still live.');
    throw error;
  });
  if (!info.size) throw new Error('Empty download');
  return file;
}

async function preparePlaylist(job, playlist, format, height, timeout) {
  const tracks = path.join(job.directory, 'tracks');
  await mkdir(tracks);
  const skipped = [];
  const total = playlist.entries.length;
  const width = String(total).length;
  for (const [index, entry] of playlist.entries.entries()) {
    job.message = 'Track ' + (index + 1) + ' of ' + total + ' · ' + entry.title;
    job.progress = 98 * index / total;
    const number = String(index + 1).padStart(width, '0');
    const work = await mkdtemp(path.join(job.directory, 'track-'));
    try {
      if (!entry.id || entry.unavailable) throw new InputError('Unavailable');
      const file = await downloadTrack(entry.id, format, height, work, true, timeout,
        percent => { job.progress = 98 * (index + percent / 100) / total; });
      const title = entry.title.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 85).trim();
      await rename(file, path.join(tracks, number + ' - ' + title + '.' + format));
    } catch (error) {
      if (error.code || /no space left|disk full|not enough space/i.test(error.message)) throw error;
      skipped.push(number + ' - ' + entry.title + ' — ' + friendly(error));
    } finally {
      await rm(work, {recursive:true, force:true});
    }
  }
  if (skipped.length === total) throw new InputError('No tracks could be saved. ' + skipped[0]);
  if (skipped.length) await writeFile(path.join(tracks, 'Skipped tracks.txt'), skipped.join('\r\n'), 'utf8');
  job.message = 'Creating your playlist ZIP…';
  job.progress = 99;
  const archive = path.join(job.directory, 'playlist.zip');
  const archiver = process.platform === 'win32' ? 'tar.exe' : 'zip';
  const args = process.platform === 'win32' ? ['-a', '-cf', archive, '--options', 'zip:compression=store', '.'] : ['-0', '-q', '-r', archive, '.'];
  await promisify(execFile)(archiver, args, {cwd:tracks, windowsHide:true});
  await rm(tracks, {recursive:true, force:true});
  job.message = 'Saved ' + (total - skipped.length) + ' of ' + total + ' tracks.' + (skipped.length ? ' See Skipped tracks.txt in the ZIP.' : '');
  return archive;
}

async function prepare(job, video, format, height, files, timeout = 3600000) {
  try {
    job.directory = await mkdtemp(path.join(files, 'spool-'));
    job.file = video.kind === 'playlist' ? await preparePlaylist(job, video, format, height, timeout)
      : await downloadTrack(video.id, format, height, job.directory, false, timeout, percent => { job.progress = percent; });
    job.bytes = (await stat(job.file)).size;
    if (!job.bytes) throw new Error('Empty download');
    job.state = 'ready';
  } catch (error) {
    job.state = 'failed';
    job.error = friendly(error);
    console.error(friendly(error));
    if (job.directory) await rm(job.directory, { recursive: true, force: true }).catch(() => {});
  } finally { job.updated = Date.now(); }
}

export { InputError, friendly, inspect, prepare };
