import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gunzipSync } from 'node:zlib';

const repo = 'EduFilesPH/spool-releases';
export const releasePage = 'https://github.com/' + repo + '/releases/latest';
const appDir = path.dirname(fileURLToPath(import.meta.url));
const versions = path.dirname(appDir);
const pkg = JSON.parse(await readFile(new URL('./package.json', import.meta.url), 'utf8'));
export const currentVersion = pkg.version;
const packaged = path.basename(versions) === 'versions' && path.basename(appDir) === currentVersion;
const versionPattern = /^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/;
const maxDownload = 8 * 1024 * 1024;

function newer(a, b) {
  const left = a.split('.').map(Number), right = b.split('.').map(Number);
  return (left[0]-right[0] || left[1]-right[1] || left[2]-right[2]) > 0;
}

async function fetchBytes(url, maxSize, purpose) {
  const response = await fetch(url, { headers: { 'User-Agent': 'Spool-Updater/' + currentVersion }, signal: AbortSignal.timeout(45000) });
  if (!response.ok) {
    await response.body?.cancel();
    throw new Error(response.status === 403 || response.status === 429
      ? 'GitHub limited this request. Try checking again later.'
      : 'Could not retrieve ' + purpose + ' from GitHub (HTTP ' + response.status + ').');
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > maxSize) throw new Error('The update exceeds the supported size.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function latest() {
  const bytes = await fetchBytes('https://api.github.com/repos/' + repo + '/releases/latest', 512 * 1024, 'the latest release');
  const release = JSON.parse(bytes);
  const version = String(release.tag_name).replace(/^v/, '');
  if (release.draft || release.prerelease || !versionPattern.test(version) || release.tag_name !== 'v' + version) {
    throw new Error('GitHub did not return a stable Spool release.');
  }
  const name = 'Spool-update-v' + version + '.json.gz';
  const asset = release.assets?.find(item => item.name === name);
  const url = 'https://github.com/' + repo + '/releases/download/v' + version + '/' + name;
  if (!asset || asset.browser_download_url !== url || !/^sha256:[0-9a-f]{64}$/.test(asset.digest) ||
      !Number.isSafeInteger(asset.size) || asset.size < 1 || asset.size > maxDownload) {
    throw new Error('The release does not contain a compatible, verifiable app update.');
  }
  return { version, url, digest: asset.digest, size: asset.size };
}

async function isStaged(version) {
  if (!packaged) return false;
  try { return (await stat(path.join(versions, version, 'server.mjs'))).isFile(); }
  catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}

export async function checkUpdate() {
  const { version } = await latest();
  return { current: currentVersion, latest: version, available: newer(version, currentVersion),
    staged: newer(version, currentVersion) && await isStaged(version), packaged };
}

async function stage(requested) {
  if (!packaged) throw new Error('Use the packaged Windows edition to install updates.');
  const release = await latest();
  if (requested !== release.version) throw new Error('The latest release changed. Check for updates again.');
  if (!newer(requested, currentVersion)) throw new Error('Spool already has this version or a newer one.');
  if (await isStaged(requested)) return { version: requested };
  const data = await fetchBytes(release.url, release.size, 'the app update');
  if (data.length !== release.size || 'sha256:' + createHash('sha256').update(data).digest('hex') !== release.digest) {
    throw new Error('The update failed verification. Your current installation is still available.');
  }
  const payload = JSON.parse(gunzipSync(data, { maxOutputLength: 24 * 1024 * 1024 }));
  if (payload.schema !== 1 || payload.version !== requested || !Array.isArray(payload.files) || payload.files.length > 256) {
    throw new Error('Unsupported update package.');
  }
  const staging = await mkdtemp(path.join(versions, '.staging-'));
  try {
    const seen = new Set();
    for (const { name, contents } of payload.files) {
      if (typeof name !== 'string' || !/^(?:public\/)?[a-z0-9][a-z0-9_-]*\.[a-z0-9]+$/.test(name) ||
          /(?:^|\/)(?:con|prn|aux|nul|com[1-9]|lpt[1-9])\./i.test(name) || seen.has(name) || typeof contents !== 'string') {
        throw new Error('Invalid file in update.');
      }
      seen.add(name);
      const destination = path.join(staging, name);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, Buffer.from(contents, 'base64'), { flag: 'wx' });
    }
    for (const name of ['package.json','server.mjs','setup.mjs','media.mjs','updates.mjs','public/index.html','public/app.js','public/style.css']) {
      if (!seen.has(name)) throw new Error('The update is incomplete.');
    }
    const metadata = JSON.parse(await readFile(path.join(staging, 'package.json'), 'utf8'));
    if (metadata.name !== 'spool-downloader' || metadata.version !== requested) throw new Error('Update version mismatch.');
    try { await rename(staging, path.join(versions, requested)); }
    catch (error) { if (!(await isStaged(requested))) throw error; }
    return { version: requested };
  } finally {
    await rm(staging, { recursive: true, force: true });
  }
}

let transfer;
export function installUpdate(version) {
  if (!transfer) transfer = stage(version).finally(() => { transfer = undefined; });
  return transfer;
}
