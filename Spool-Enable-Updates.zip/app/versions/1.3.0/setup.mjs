import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, rename, rm } from 'node:fs/promises';
import { homedir } from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGunzip } from 'node:zlib';

const windows = process.platform === 'win32';
export const dataDirectory = windows
  ? path.join(process.env.LOCALAPPDATA || path.join(homedir(), 'AppData', 'Local'), 'SpoolDownloader')
  : path.join(homedir(), '.local', 'share', 'spool-downloader');
const tools = path.join(dataDirectory, 'tools');
export const downloader = windows ? path.join(tools, 'yt-dlp-2026.11.23.exe') : 'yt-dlp';
export const ffmpeg = windows ? path.join(tools, 'ffmpeg-b6.1.1.exe') : undefined;

async function checksum(filename) {
  const hash = createHash('sha256');
  try {
    for await (const chunk of createReadStream(filename)) hash.update(chunk);
    return hash.digest('hex');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return null;
  }
}

async function install(name, destination, url, expected, compressed = false) {
  if (await checksum(destination) === expected) return;
  console.log('Downloading ' + name + ' for this PC…');
  const temporary = destination + '.' + randomUUID() + '.part';
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(300000) });
    if (!response.ok || !response.body) throw new Error(name + ' download failed (HTTP ' + response.status + ').');
    const streams = [Readable.fromWeb(response.body)];
    if (compressed) streams.push(createGunzip());
    await pipeline(...streams, createWriteStream(temporary, { flags: 'wx' }));
    if (await checksum(temporary) !== expected) throw new Error(name + ' failed its checksum check. Reopen Spool to retry.');
    try { await rename(temporary, destination); }
    catch (error) { if (await checksum(destination) !== expected) throw error; }
    console.log(name + ' is ready.');
  } finally {
    await rm(temporary, { force: true });
  }
}

export async function ensureTools() {
  if (!windows) return;
  if (process.arch !== 'x64') throw new Error('Use the Windows x64 edition of Spool.');
  await mkdir(tools, { recursive: true });
  await install('yt-dlp', downloader,
    'https://github.com/yt-dlp/yt-dlp/releases/download/2026.11.23/yt-dlp.exe',
    '622ed48023cac1daa52a3bf3a6ac38f03514de214b5f0fa069389fd0f6d17e5c');
  await install('FFmpeg', ffmpeg,
    'https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-win32-x64.gz',
    '04e1307997530f9cf2fe35cba2ca7e8875ca91da02f89d6c7243df819c94ad00', true);
}
