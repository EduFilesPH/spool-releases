import { spawn } from 'node:child_process';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { downloader, ffmpeg } from './setup.mjs';
const metadata = new Map();

class InputError extends Error {}
function videoId(input) {
  let url;
  try {
    const raw = String(input).trim();
    url = new URL(/^https?:\/\//i.test(raw) ? raw : 'https://' + raw);
  } catch { throw new InputError('Paste a valid YouTube video or Shorts link.'); }
  const host = url.hostname.toLowerCase();
  const parts = url.pathname.split('/');
  let id;
  if (host === 'youtu.be') id = parts[1];
  if (['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'].includes(host)) {
    if (url.pathname === '/watch') id = url.searchParams.get('v');
    else if (['shorts', 'live', 'embed'].includes(parts[1])) id = parts[2];
  }
  if (!/^[\w-]{11}$/.test(id || '')) throw new InputError('Use a link to one YouTube video or Short.');
  return id;
}

function run(args, timeout, onProgress) {
  return new Promise((resolve, reject) => {
    const proc = spawn(downloader, ['--ignore-config', '--no-playlist', '--no-warnings',
      '--encoding', 'utf-8', '--js-runtimes', 'node:' + process.execPath,
      ...(ffmpeg ? ['--ffmpeg-location', ffmpeg] : []), '--socket-timeout', '20', '--retries', '2', ...args],
      { windowsHide: true, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '', errors = '', partial = '';
    const timer = setTimeout(() => proc.kill(), timeout);
    proc.stdout.setEncoding('utf8').on('data', chunk => {
      if (!onProgress) { output += chunk; return; }
      const lines = (partial + chunk).split(/\r?\n/);
      partial = lines.pop();
      lines.forEach(onProgress);
    });
    proc.stderr.setEncoding('utf8').on('data', chunk => { errors = (errors + chunk).slice(-4000); });
    proc.on('error', err => { clearTimeout(timer); reject(err); });
    proc.on('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve(output);
      else reject(new Error(errors.trim() || 'The download timed out or was interrupted.'));
    });
  });
}

function friendly(error) {
  if (error instanceof InputError) return error.message;
  const detail = error.message;
  if (/private|unavailable|removed|not available|members.only/i.test(detail)) return 'YouTube says this video is unavailable. Try another public video.';
  if (/sign in|bot|429|403|age.restricted/i.test(detail)) return 'YouTube restricted this request. Try another public video or try again later.';
  if (/format is not available/i.test(detail)) return 'That format is no longer available. Fetch the link again to refresh the options.';
  if (/ENOENT|ffmpeg not found/i.test(detail)) return 'A media tool is missing. Close Spool and open it again to restore the tools.';
  return 'The request could not finish. Check your connection and try again.';
}

let lookups = 0;
async function inspect(input) {
  const id = videoId(input);
  const cached = metadata.get(id);
  if (cached && Date.now() - cached.time < 600000) return cached.data;
  if (lookups >= 4) throw new InputError('Other links are loading. Try again in a moment.');
  lookups++;
  try {
    const raw = JSON.parse(await run(['--dump-single-json', '--skip-download', '--', 'https://www.youtube.com/watch?v=' + id], 90000));
    if (raw.is_live || raw.live_status === 'is_upcoming') throw new InputError('Choose a finished video. Live broadcasts can be saved after they end.');
    const videoFormats = raw.formats.filter(f => f.ext === 'mp4' && !f.has_drm &&
      f.vcodec && f.vcodec !== 'none' && Number.isInteger(f.height) && f.height > 0);
    const choices = [...new Set(videoFormats.map(f => f.height))].sort((a,b) => b-a);
    const data = { id, title: raw.title, channel: raw.uploader || raw.channel || 'YouTube',
      duration: raw.duration || 0, qualities: choices, thumbnail: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' };
    if (metadata.size >= 100) metadata.delete(metadata.keys().next().value);
    metadata.set(id, { time: Date.now(), data });
    return data;
  } finally { lookups--; }
}

async function prepare(job, video, format, height, files, timeout = 3600000) {
  try {
    job.directory = await mkdtemp(path.join(files, 'spool-'));
    const options = format === 'mp3'
      ? ['-f', 'bestaudio/best', '-x', '--audio-format', 'mp3', '--audio-quality', '2']
      : ['-f', 'bv[ext=mp4][height=' + height + ']+ba[ext=m4a]/b[ext=mp4][height=' + height + ']/bv[ext=mp4][height=' + height + ']+ba', '--merge-output-format', 'mp4'];
    await run([...options, '--newline', '--progress', '--progress-template', 'download:PROGRESS %(progress._percent_str)s',
      '-o', path.join(job.directory, 'video.%(ext)s'), '--', 'https://www.youtube.com/watch?v=' + video.id], timeout, line => {
      const match = /^PROGRESS\s+([\d.]+)%/.exec(line);
      if (match) job.progress = Math.min(99, Number(match[1]));
    });
    job.file = path.join(job.directory, 'video.' + format);
    job.bytes = (await stat(job.file)).size;
    if (!job.bytes) throw new Error('Empty download');
    job.state = 'ready';
  } catch (error) {
    job.state = 'failed';
    job.error = friendly(error);
    console.error(friendly(error));
    if (job.directory) await rm(job.directory, { recursive: true, force: true }).catch(() => {});
  } finally { job.updated = Date.now(); }
}

export { InputError, friendly, inspect, prepare };
