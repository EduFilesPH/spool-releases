import http from 'node:http';
import { spawn } from 'node:child_process';
import { InputError, friendly, inspect, prepare } from './media.mjs';
import { dataDirectory, ensureTools } from './setup.mjs';
import { randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, readdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pipeline } from 'node:stream/promises';
import { checkUpdate, currentVersion, installUpdate } from './updates.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const files = path.join(dataDirectory, 'temporary');
const preferredPort = Number(process.env.PORT || 4173);
const openOnStart = process.argv.includes('--open-browser');
const jobs = new Map();
const formats = new Set(['mp4', 'mp3']);
await ensureTools();
await mkdir(files, { recursive: true });

async function readBody(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 6000) throw new InputError('The submitted link is too long.');
  }
  try { return JSON.parse(body) || {}; } catch { throw new InputError('Invalid request.'); }
}
const staticFiles = new Map([['/', ['index.html','text/html; charset=utf-8']], ['/app.js',['app.js','text/javascript']],
  ['/style.css',['style.css','text/css']], ['/cassette.webp',['cassette.webp','image/webp']], ['/icon.svg',['icon.svg','image/svg+xml']]]);
const server = http.createServer(async (req, res) => {
  const json = (status, data) => { res.writeHead(status, {'Content-Type':'application/json','Cache-Control':'no-store'}); res.end(JSON.stringify(data)); };
  try {
    const port = req.socket.localPort;
    if (!['127.0.0.1:' + port, 'localhost:' + port].includes(req.headers.host)) return json(403, { error: 'Unknown hostname.' });
    const origin = 'http://' + req.headers.host;
    if (req.method === 'POST' && (req.headers['content-type'] !== 'application/json' ||
      (req.headers.origin && req.headers.origin !== origin))) return json(403, {error:'Submit the link from the Spool app.'});
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('X-Frame-Options','DENY');
    const route = new URL(req.url, 'http://localhost').pathname;
    if (req.method === 'GET' && route === '/api/status') return json(200, { app: 'spool-desktop', version: 1, appVersion: currentVersion });
    if (req.method === 'POST' && ['/api/updates/check','/api/updates/install'].includes(route)) {
      const body = await readBody(req);
      try {
        const result = route.endsWith('/check') ? await checkUpdate() : await installUpdate(body.version);
        return json(200, result);
      } catch (error) {
        console.error('Update:', error.message);
        const message = error.code === 'EACCES' || error.code === 'EPERM'
          ? 'Spool cannot write to this folder. Move the extracted app to a folder you own and try again.'
          : error.message === 'fetch failed' ? 'Could not reach GitHub. Check your internet connection and try again.' : error.message;
        return json(502, { error: message });
      }
    }
    if (req.method === 'POST' && route === '/api/video') {
      return json(200, await inspect((await readBody(req)).url));
    }
    if (req.method === 'POST' && route === '/api/jobs') {
      const {url, format, height} = await readBody(req);
      if (!formats.has(format)) throw new InputError('Choose MP4 video or MP3 audio.');
      const video = await inspect(url);
      if (format === 'mp4' && !video.qualities.includes(height)) throw new InputError('Choose an available resolution.');
      if ([...jobs.values()].filter(j => j.state === 'working').length >= 2) return json(429,{error:'Two downloads are running. Try again when one finishes.'});
      const id = randomUUID();
      const job = { state:'working', progress:0, name:video.title.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0,120) + '.' + format, format };
      jobs.set(id, job);
      void prepare(job, video, format, height, files);
      return json(202,{id});
    }
    const match = /^\/api\/jobs\/([\w-]+)(\/file)?$/.exec(route);
    if (req.method === 'GET' && match) {
      const job = jobs.get(match[1]);
      if (!job) return json(404, {error:'This file has expired. Fetch the video again.'});
      if (!match[2]) return json(200, { state:job.state, progress:job.progress, error:job.error });
      if (job.state !== 'ready') return json(409, {error:'This file is still being prepared.'});
      res.writeHead(200, {'Cache-Control':'private, no-store','Content-Type':job.format === 'mp4' ? 'video/mp4' : 'audio/mpeg','Content-Length':job.bytes,
        'Content-Disposition':"attachment; filename*=UTF-8''" + encodeURIComponent(job.name).replace(/'/g,'%27')});
      await pipeline(createReadStream(job.file), res);
      return;
    }
    if (req.method === 'GET' && staticFiles.has(route)) {
      const [file, type] = staticFiles.get(route);
      const location = path.join(root, 'public', file);
      const info = await stat(location);
      res.writeHead(200, {'Content-Type':type, 'Content-Length':info.size});
      await pipeline(createReadStream(location), res);
      return;
    }
    json(404,{error:'Page not found.'});
  } catch (err) {
    if (!res.headersSent && !res.destroyed) json(err instanceof InputError ? 400 : 502, {error:friendly(err)});
  }
});

// Remove completed files after an hour, including files left behind by an earlier run.
async function cleanup() {
  const cutoff = Date.now() - 3600000;
  for (const [id, job] of jobs) {
    if (job.updated && job.updated < cutoff) jobs.delete(id);
  }
  const active = new Set([...jobs.values()].map(j => j.directory));
  for (const entry of await readdir(files, {withFileTypes:true})) {
    if (!entry.isDirectory() || !entry.name.startsWith('spool-')) continue;
    const dir = path.join(files, entry.name);
    if (!active.has(dir) && (await stat(dir)).mtimeMs < cutoff) await rm(dir,{recursive:true,force:true});
  }
}
function showAddress(port) {
  const url = 'http://127.0.0.1:' + port + '/';
  console.log('Spool is ready at ' + url);
  if (openOnStart && process.platform === 'win32') {
    const browser = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], { windowsHide: true, stdio: 'ignore' });
    browser.on('error', () => console.log('Open the address above in your browser.'));
    browser.unref();
  }
}

let listenPort = preferredPort;
server.on('error', async error => {
  if (error.code !== 'EADDRINUSE' || !openOnStart || listenPort >= preferredPort + 10) throw error;
  try {
    const response = await fetch('http://127.0.0.1:' + listenPort + '/api/status', { signal: AbortSignal.timeout(800), redirect: 'error' });
    const status = await response.json();
    if (status.app === 'spool-desktop' && status.version === 1) {
      showAddress(listenPort);
      return;
    }
  } catch {}
  server.listen(++listenPort, '127.0.0.1');
});
server.on('listening', () => {
  showAddress(server.address().port);
  console.log('Keep this window open while using Spool. Close it to stop.');
  cleanup().catch(console.error);
  setInterval(() => cleanup().catch(console.error), 600000).unref();
});
server.listen(listenPort, '127.0.0.1');
