// Stable entry point shared by full installations and the 1.0 migration patch.
import { readdir, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const versions = new URL('./versions/', import.meta.url);
const installed = (await readdir(versions, { withFileTypes: true }))
  .filter(entry => entry.isDirectory() && /^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(entry.name))
  .map(entry => entry.name);
installed.sort((a, b) => {
  const left = a.split('.').map(Number), right = b.split('.').map(Number);
  return right[0]-left[0] || right[1]-left[1] || right[2]-left[2];
});
if (!installed.length) throw new Error('No installed Spool version was found. Extract the app update again.');
const entry = new URL(installed[0] + '/server.mjs', versions);
await stat(fileURLToPath(entry));
await import(entry.href);
